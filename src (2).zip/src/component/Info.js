import React, { Component } from "react";

export default class Info extends Component {
    render(){
        return(
            <div>
                <h1>Аба ырайы приложениясы</h1>
                <p>озунуздун шаарыныздагы пагоданы билиниз</p>
            </div>
        )
    }

}