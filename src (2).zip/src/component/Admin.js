import React from 'react';

const Admin = () => {
    return (
        <div className='admin'>
          
          
        </div>
    );
}

export default Admin;
